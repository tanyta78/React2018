export default {
	defaultState: {
		content: '',
		courseId: '',
		username:''
	}
};