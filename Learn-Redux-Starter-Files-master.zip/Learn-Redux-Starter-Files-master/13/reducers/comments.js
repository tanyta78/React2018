function comments(state = [], action) {
  return state;
}

export default comments;
